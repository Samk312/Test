import Box from './components/Box/aphrodite';
import View from './components/View/aphrodite';

export default {
  Box,
  View
};
