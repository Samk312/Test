import Box from './components/Box/reactxp';
import { View } from 'reactxp';

export default {
  Box,
  View
};
