import Box from './components/Box/glamor';
import View from './components/View/glamor';

export default {
  Box,
  View
};
