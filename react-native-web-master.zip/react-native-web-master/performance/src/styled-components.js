import Box from './components/Box/styled-components';
import View from './components/View/styled-components';

export default {
  Box,
  View
};
