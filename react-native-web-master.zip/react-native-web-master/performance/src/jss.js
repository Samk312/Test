import Box from './components/Box/jss';
import View from './components/View/jss';

export default {
  Box,
  View
};
