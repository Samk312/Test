import Box from './components/Box/css-modules';
import View from './components/View/css-modules';

export default {
  Box,
  View
};
