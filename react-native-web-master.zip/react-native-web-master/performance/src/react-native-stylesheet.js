import Box from './components/Box/react-native-stylesheet';
import View from './components/View/react-native-stylesheet';

export default {
  Box,
  View
};
