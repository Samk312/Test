// NativeModules shim
module.exports = {};
