import { findDOMNode } from 'react-dom';
export default findDOMNode;
