import StyleRegistry from './StyleRegistry';
const registry = new StyleRegistry();
module.exports = registry;
