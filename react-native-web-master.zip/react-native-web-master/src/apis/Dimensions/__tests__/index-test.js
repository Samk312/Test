/* eslint-env jasmine, jest */

describe('apis/Dimensions', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
