/* eslint-env jasmine, jest */

describe('components/Button', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
