/* eslint-env jasmine, jest */

describe('components/ScrollView', () => {
  test('NO TEST COVERAGE');
});
