/* eslint-env jasmine, jest */

describe('components/Touchable', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
