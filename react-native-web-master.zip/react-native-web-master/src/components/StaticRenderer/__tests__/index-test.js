/* eslint-env jasmine, jest */

describe('components/StaticRenderer', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
