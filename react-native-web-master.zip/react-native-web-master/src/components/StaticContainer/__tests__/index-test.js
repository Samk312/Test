/* eslint-env jasmine, jest */

describe('components/StaticContainer', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
