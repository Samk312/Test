/* eslint-env jasmine, jest */

describe('components/ListView', () => {
  test('NO TEST COVERAGE');
});
