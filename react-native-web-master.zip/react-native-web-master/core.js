module.exports = require('./dist/core')
