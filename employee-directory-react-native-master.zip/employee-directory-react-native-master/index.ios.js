import {AppRegistry} from 'react-native';

import EmployeeDirectoryApp from './app/EmployeeDirectoryApp';

AppRegistry.registerComponent('EmployeeDirectory', () => EmployeeDirectoryApp);