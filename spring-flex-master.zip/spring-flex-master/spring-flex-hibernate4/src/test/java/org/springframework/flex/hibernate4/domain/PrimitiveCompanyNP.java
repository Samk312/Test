package org.springframework.flex.hibernate4.domain;


public class PrimitiveCompanyNP {

    public int id;

    public int version;

    public String name;

}
