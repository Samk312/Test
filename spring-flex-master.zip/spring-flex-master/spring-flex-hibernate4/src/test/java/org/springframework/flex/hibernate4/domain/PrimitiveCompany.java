package org.springframework.flex.hibernate4.domain;


public class PrimitiveCompany {

    private int id;

    private int version;

    private String name;

    
    public int getId() {
        return id;
    }

    
    public void setId(int id) {
        this.id = id;
    }

    
    public int getVersion() {
        return version;
    }

    
    public void setVersion(int version) {
        this.version = version;
    }

    
    public String getName() {
        return name;
    }

    
    public void setName(String name) {
        this.name = name;
    }

}
