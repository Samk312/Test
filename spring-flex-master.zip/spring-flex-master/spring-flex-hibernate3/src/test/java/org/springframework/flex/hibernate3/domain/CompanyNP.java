package org.springframework.flex.hibernate3.domain;



public class CompanyNP {

    public Integer id;

    public Integer version;

    public String name;

}
