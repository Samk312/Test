package org.springframework.flex.hibernate3.domain;


public class PrimitiveCompanyNP {

    public int id;

    public int version;

    public String name;

}
