package org.springframework.flex.integration.util;


public interface DbInitializer {

	void init();

}
